clc, clear, close all;

n = 64; % because 58+6 == next whole number divisible by 16 [size of setup rule binary array]
run dataImportAll.m;

% motionControlled = IThinkThatIWouldLikeToUseTheSystemFrequentlyExperiment1;
% eyeControlled = IThinkThatIWouldLikeToUseTheSystemFrequentlyExperiment2; 
initialDataExpereiment1 = horzcat(A,C,E,G,I,K,M,O,Q,S);
initialDataExpereiment2 = horzcat(B,D,F,H,J,L,N,P,R,T);

reformingArray = zeros(n - length(initialDataExpereiment1), 10);

initialDataExpereiment1refined = [initialDataExpereiment1; reformingArray];
initialDataExpereiment2refined = [initialDataExpereiment2; reformingArray];

% setup rule for control
setupRule = zeros(8, 1);
setupRule1 = [setupRule; ones(8, 1)];
setupRule2 = [ones(8, 1); setupRule];

for i = 1:2 % length of for loop is size/16/2 == 19
    setupRule1 = [setupRule1; setupRule1];
    setupRule2 = [setupRule2; setupRule2];
end

% setup rule for eye gate
eyegateSetup1 = zeros(length(A), 1);
eyegateSetup2 = ones(length(A), 1);

for i = 1 : length(eyegateSetup1)
    if(mod(i,2) == 0)
        eyegateSetup1(i) = 1;
        eyegateSetup2(i) = 0;
    end
end

[rows, cols] = size(initialDataExpereiment1refined);

for i = 1 : cols
    motionControlled1(:, i) = initialDataExpereiment1refined(:, i).*setupRule1;
    eyeControlled1(:, i) = initialDataExpereiment2refined(:, i).*setupRule2;
    eyegateOn2(:, i) = initialDataExpereiment1(:, i).*eyegateSetup1;
    eyegateOff2(:, i) = initialDataExpereiment2(:, i).*eyegateSetup2;
end

expereiment2Data = motionControlled1 + eyeControlled1; %%% cleaned eye control data
eyegate2Data = eyegateOn2 + eyegateOff2; %%% cleaned eye gate data

for i = 1 : cols
    motionControlled3 = initialDataExpereiment1refined.*setupRule2;
    eyeControlled3 = initialDataExpereiment2refined.*setupRule1;
    eyegateOn1(:, i) = initialDataExpereiment1(:, i).*eyegateSetup2;
    eyegateOff1(:, i) = initialDataExpereiment2(:, i).*eyegateSetup1;
end

expereiment1Data = motionControlled3 + eyeControlled3; %%% cleaned motion control data
eyegate1Data = eyegateOn1 + eyegateOff1; %%% cleaned eye gate data



% final outputs
DataVariables.handControl = expereiment1Data(1:58,1:10);
DataVariables.eyegazeControl = expereiment2Data(1:58,1:10);
DataVariables.eyeGateOn = eyegate1Data;
DataVariables.eyeGateOff = eyegate2Data;

%% finding raw score

[rowsDV, colsDV] = size(DataVariables.handControl);
% processing1 = zeros(rowsDV, colsDV);

for i = 1 : colsDV
    if(mod(i, 2) == 0)
        processing1(:, i) = 5 - DataVariables.handControl(:, i);
        processing2(:, i) = 5 - DataVariables.eyegazeControl(:, i);
        processing3(:, i) = 5 - DataVariables.eyeGateOn(:, i);
        processing4(:, i) = 5 - DataVariables.eyeGateOff(:, i);
    else
        processing1(:, i) = DataVariables.handControl(:, i) - 1;
        processing2(:, i) = DataVariables.eyegazeControl(:, i) - 1;
        processing3(:, i) = DataVariables.eyeGateOn(:, i) - 1;
        processing4(:, i) = DataVariables.eyeGateOff(:, i) - 1;
    end
end


for i = 2 : colsDV
    DataVariables.handControl(:, colsDV + 1) = processing1(:, i - 1) + processing1(:, i);
    DataVariables.eyegazeControl(:, colsDV + 1) = processing2(:, i - 1) + processing2(:, i);
    DataVariables.eyeGateOn(:, colsDV + 1) = processing3(:, i - 1) + processing3(:, i);
    DataVariables.eyeGateOff(:, colsDV + 1) = processing4(:, i - 1) + processing4(:, i);
end

clear processing1 processing2 processing3 processing4;

% raw score avg
DataVariables.handControl(rowsDV + 1, colsDV + 1) = mean(DataVariables.handControl(:, colsDV + 1));
DataVariables.eyegazeControl(rowsDV + 1, colsDV + 1) = mean(DataVariables.eyegazeControl(:, colsDV + 1));
DataVariables.eyeGateOn(rowsDV + 1, colsDV + 1) = mean(DataVariables.eyeGateOn(:, colsDV + 1));
DataVariables.eyeGateOff(rowsDV + 1, colsDV + 1) = mean(DataVariables.eyeGateOff(:, colsDV + 1));

rawScoreAvg.handControl = DataVariables.handControl(rowsDV + 1, colsDV + 1);
rawScoreAvg.eyegazeControl = DataVariables.eyegazeControl(rowsDV + 1, colsDV + 1);
rawScoreAvg.eyeGateOn = DataVariables.eyeGateOn(rowsDV + 1, colsDV + 1);
rawScoreAvg.eyeGateOff = DataVariables.eyeGateOff(rowsDV + 1, colsDV + 1);

%% finding sus score

[rowsDV, colsDV] = size(DataVariables.handControl);

DataVariables.handControl(:, colsDV + 1) = DataVariables.handControl(:, colsDV).*2.5;
DataVariables.eyegazeControl(:, colsDV + 1) = DataVariables.eyegazeControl(:, colsDV).*2.5;
DataVariables.eyeGateOn(:, colsDV + 1) = DataVariables.eyeGateOn(:, colsDV).*2.5;
DataVariables.eyeGateOff(:, colsDV + 1) = DataVariables.eyeGateOff(:, colsDV).*2.5;

% sus score avg
DataVariables.handControl(rowsDV, colsDV + 1) = mean(DataVariables.handControl(:, colsDV + 1));
DataVariables.eyegazeControl(rowsDV, colsDV + 1) = mean(DataVariables.eyegazeControl(:, colsDV + 1));
DataVariables.eyeGateOn(rowsDV, colsDV + 1) = mean(DataVariables.eyeGateOn(:, colsDV + 1));
DataVariables.eyeGateOff(rowsDV, colsDV + 1) = mean(DataVariables.eyeGateOff(:, colsDV + 1));

susScoreAvg.handControl = DataVariables.handControl(rowsDV, colsDV + 1);
susScoreAvg.eyegazeControl = DataVariables.eyegazeControl(rowsDV, colsDV + 1);
susScoreAvg.eyeGateOn = DataVariables.eyeGateOn(rowsDV, colsDV + 1);
susScoreAvg.eyeGateOff = DataVariables.eyeGateOff(rowsDV, colsDV + 1);

%% comparisons

% w/o averaging
% xData = categorical({'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
% xData = reordercats(xData, {'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
% yData = [susScoreAvg.eyeGateOff susScoreAvg.eyeGateOn susScoreAvg.eyeGateOff ...
%     susScoreAvg.eyeGateOn; susScoreAvg.handControl susScoreAvg.handControl ...
%     susScoreAvg.eyegazeControl susScoreAvg.eyegazeControl];
% figure(1)
% bar(xData, yData)

% with averaging
xData = categorical({'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
xData = reordercats(xData, {'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
yData = [mean(susScoreAvg.eyeGateOff + susScoreAvg.handControl); ...
         mean(susScoreAvg.eyeGateOn + susScoreAvg.handControl); ...
         mean(susScoreAvg.eyeGateOff + susScoreAvg.eyegazeControl); ...
         mean(susScoreAvg.eyeGateOn + susScoreAvg.eyegazeControl)];
figure(2)
b = bar(xData, yData);

% HC w/o EG vs EC w/o EG with averaging
xData = categorical({'HC w/o EG', 'EC w/o EG'});
xData = reordercats(xData, {'HC w/o EG', 'EC w/o EG'});
yData = [mean(susScoreAvg.eyeGateOff + susScoreAvg.handControl); ...
         mean(susScoreAvg.eyeGateOff + susScoreAvg.eyegazeControl)];
figure(3)
bar(xData, yData);

figure(4)
% HC w/o EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateOff(1:58, 12), DataVariables.handControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'HC w/o EG';
gcf(2).DisplayName = 'EC w/o EG';
legend; grid on;

figure(5)
% HC w EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateon(1:58, 12), DataVariables.handControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'HC w EG';
gcf(2).DisplayName = 'EC w/o EG';
legend; grid on;

figure(6)
% EC w EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateon(1:58, 12), DataVariables.eyegazeControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'EC w EG ';
gcf(2).DisplayName = 'EC w/o EG ';
legend; grid on;



