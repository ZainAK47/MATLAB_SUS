clc, clear, close all;

susData = readtable('susTable.xlsx');
A = summary(susData);

handControl.mean = mean(susData.handcontrol);
handControl.std = std(susData.handcontrol);
handControl.var = var(susData.handcontrol);
handControl.median = median(susData.handcontrol);
handControl.mode = mode(susData.handcontrol);

eyegazeControl.mean = mean(susData.eyegazeControl);
eyegazeControl.std = std(susData.eyegazeControl);
eyegazeControl.var = var(susData.eyegazeControl);
eyegazeControl.median = median(susData.eyegazeControl);
eyegazeControl.mode = mode(susData.eyegazeControl);

eyeGateOff.mean = mean(susData.eyeGateOff);
eyeGateOff.std = std(susData.eyeGateOff);
eyeGateOff.var = var(susData.eyeGateOff);
eyeGateOff.median = median(susData.eyeGateOff);
eyeGateOff.mode = mode(susData.eyeGateOff);

eyeGateOn.mean = mean(susData.eyeGateOn);
eyeGateOn.std = std(susData.eyeGateOn);
eyeGateOn.var = var(susData.eyeGateOn);
eyeGateOn.median = median(susData.eyeGateOn);
eyeGateOn.mode = mode(susData.eyeGateOn);

clear eyeGateOn eyeGateOff eyegazeControl handControl;
%% ANOVA data

dataVars = readtable('datavaraibles.xlsx');
B = summary(dataVars);

HCwithEGOff.mean = mean(dataVars.HCwithEGOff);
HCwithEGOff.std = std(dataVars.HCwithEGOff);
HCwithEGOff.var = var(dataVars.HCwithEGOff);
HCwithEGOff.median = median(dataVars.HCwithEGOff);
HCwithEGOff.mode = mode(dataVars.HCwithEGOff);

HCwithEGOn.mean = mean(dataVars.HCwithEGOn);
HCwithEGOn.std = std(dataVars.HCwithEGOn);
HCwithEGOn.var = var(dataVars.HCwithEGOn);
HCwithEGOn.median = median(dataVars.HCwithEGOn);
HCwithEGOn.mode = mode(dataVars.HCwithEGOn);

ECwithEGOff.mean = mean(dataVars.ECwithEGOff);
ECwithEGOff.std = std(dataVars.ECwithEGOff);
ECwithEGOff.var = var(dataVars.ECwithEGOff);
ECwithEGOff.median = median(dataVars.ECwithEGOff);
ECwithEGOff.mode = mode(dataVars.ECwithEGOff);

ECwithEGOn.mean = mean(dataVars.ECwithEGOn);
ECwithEGOn.std = std(dataVars.ECwithEGOn);
ECwithEGOn.var = var(dataVars.ECwithEGOn);
ECwithEGOn.median = median(dataVars.ECwithEGOn);
ECwithEGOn.mode = mode(dataVars.ECwithEGOn);

HCwithEG = [dataVars.HCwithEGOn; dataVars.HCwithEGOff];
ECwithEG = [dataVars.ECwithEGOn; dataVars.ECwithEGOff];

experiment = [HCwithEG, ECwithEG];
% clear ECwithEGOn ECwithEGOff HCwithEGOn HCwithEGOff

% Two-way ANOVA
[~, ~, stats1] = anova2(experiment, 58, 'off');
c = multcompare(stats1);

% Friedmans Test
[p, tb1, stats2] = friedman(experiment, 58);
d = multcompare(stats2);

% how to interpret stats with popcorn example
% stats = struct with fields:
%       source: 'anova2'
%      sigmasq: 0.1389
%     colmeans: [6.2500 4.7500 4]
%         coln: 6
%     rowmeans: [4.5000 5.5000]
%         rown: 9
%        inter: 1
%         pval: 0.7462
%           df: 12
% 
% The stats structure includes: 
% The mean squared error (sigmasq) 
% The estimates of the mean yield for each popcorn brand (colmeans) 
% The number of observations for each popcorn brand (coln) 
% The estimate of the mean yield for each popper type (rowmeans) 
% The number of observations for each popper type (rown) 
% The number of interactions (inter) 
% The p-value that shows the significance level of the interaction term (pval) 
% The error degrees of freedom (df).