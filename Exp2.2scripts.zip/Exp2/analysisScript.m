clc, clear, close all;

n = 64; % because 58+6 == next whole number divisible by 16 [size of setup rule binary array]
run dataImportAll.m;

% motionControlled = IThinkThatIWouldLikeToUseTheSystemFrequentlyExperiment1;
% eyeControlled = IThinkThatIWouldLikeToUseTheSystemFrequentlyExperiment2; 
initialDataExpereiment1 = horzcat(A,C,E,G,I,K,M,O,Q,S);
initialDataExpereiment2 = horzcat(B,D,F,H,J,L,N,P,R,T);

reformingArray = zeros(n - length(initialDataExpereiment1), 10);

initialDataExpereiment1refined = [initialDataExpereiment1; reformingArray];
initialDataExpereiment2refined = [initialDataExpereiment2; reformingArray];

% setup rule for control
setupRule = zeros(8, 1);
setupRule1 = [setupRule; ones(8, 1)];
setupRule2 = [ones(8, 1); setupRule];

for i = 1:2 % length of for loop is size/16/2 == 19
    setupRule1 = [setupRule1; setupRule1];
    setupRule2 = [setupRule2; setupRule2];
end

% setup rule for eye gate
eyegateSetup1 = zeros(length(A), 1);
eyegateSetup2 = ones(length(A), 1);

clear reformingArray A B C D E F G H I J K L M N O P Q R S T;

for i = 1 : length(eyegateSetup1)
    if(mod(i,2) == 0)
        eyegateSetup1(i) = 1;
        eyegateSetup2(i) = 0;
    end
end

[~, cols] = size(initialDataExpereiment1refined);

% experiment 1 setup
HCwithEGOnSetup1 = setupRule1(1:58).*eyegateSetup1;
HCwithEGOffSetup1 = setupRule1(1:58).*eyegateSetup2;
ECwithEGOnSetup1 = setupRule2(1:58).*eyegateSetup1;
ECwithEGOffSetup1 = setupRule2(1:58).*eyegateSetup2;

% experiment 2 setup
HCwithEGOnSetup2 = setupRule2(1:58).*eyegateSetup2;
HCwithEGOffSetup2 = setupRule2(1:58).*eyegateSetup1;
ECwithEGOnSetup2 = setupRule1(1:58).*eyegateSetup2;
ECwithEGOffSetup2 = setupRule1(1:58).*eyegateSetup1;

% combining outcomes xor operation
HCwithEGOffSetup = HCwithEGOffSetup2 + HCwithEGOffSetup1;
HCwithEGOnSetup = HCwithEGOnSetup1 + HCwithEGOnSetup2;
ECwithEGOnSetup = ECwithEGOnSetup2 + ECwithEGOnSetup1;
ECwithEGOffSetup = ECwithEGOffSetup2 + ECwithEGOffSetup1;

% make sure HCwithEGOffSetup HCwithEGOnSetup ECwithEGOnSetup ECwithEGOffSetup
% are strictly binary arrays by normalizing setup arrays; check output of
% this for loop
for i = 1 : length(HCwithEGOffSetup)
    if (HCwithEGOnSetup(i)) > 1
        HCwithEGOnErrorPoints = [HCwithEGOnErrorPoints; HCwithEGOnSetup(i)];
    end
    if (HCwithEGOffSetup(i)) > 1
        HCwithEGOffErrorPoints = [HCwithEGOffErrorPoints; HCwithEGOffSetup(i)];
    end
    if (ECwithEGOnSetup(i)) > 1
        ECwithEGOnErrorPoints = [ECwithEGOnErrorPoints; ECwithEGOnSetup(i)];
    end
    if (ECwithEGOffSetup(i)) > 1
        ECwithEGOffErrorPoints = [ECwithEGOffErrorPoints; ECwithEGOffSetup(i)];
    end
end

for i = 1 : cols
    motionControlled1(:, i) = initialDataExpereiment1refined(:, i).*setupRule1;
    eyeControlled1(:, i) = initialDataExpereiment2refined(:, i).*setupRule2;
    eyegateOn2(:, i) = initialDataExpereiment1(:, i).*eyegateSetup1;
    eyegateOff2(:, i) = initialDataExpereiment2(:, i).*eyegateSetup2;
    HCwithEGOn1(:, i) = initialDataExpereiment1refined(1:58, i).*HCwithEGOnSetup1;
    HCwithEGOff1(:, i) = initialDataExpereiment1refined(1:58, i).*HCwithEGOffSetup1;
    ECwithEGOn1(:, i) = initialDataExpereiment1refined(1:58, i).*ECwithEGOnSetup1;
    ECwithEGOff1(:, i) = initialDataExpereiment1refined(1:58, i).*ECwithEGOffSetup1;
end

expereiment2Data = motionControlled1 + eyeControlled1; %%% cleaned eye control data
eyegate2Data = eyegateOn2 + eyegateOff2; %%% cleaned eye gate data

for i = 1 : cols
    motionControlled3 = initialDataExpereiment1refined.*setupRule2;
    eyeControlled3 = initialDataExpereiment2refined.*setupRule1;
    eyegateOn1(:, i) = initialDataExpereiment1(:, i).*eyegateSetup2;
    eyegateOff1(:, i) = initialDataExpereiment2(:, i).*eyegateSetup1;
    HCwithEGOn2(:, i) = initialDataExpereiment2refined(1:58, i).*HCwithEGOnSetup2;
    HCwithEGOff2(:, i) = initialDataExpereiment2refined(1:58, i).*HCwithEGOffSetup2;
    ECwithEGOn2(:, i) = initialDataExpereiment2refined(1:58, i).*ECwithEGOnSetup2;
    ECwithEGOff2(:, i) = initialDataExpereiment2refined(1:58, i).*ECwithEGOffSetup2;
end

clear HCwithEGOffSetup HCwithEGOnSetup ECwithEGOnSetup ECwithEGOffSetup;

clear ECwithEGOffSetup1 ECwithEGOffSetup2 ECwithEGOnSetup1 ECwithEGOnSetup2;
clear HCwithEGOffSetup2 HCwithEGOffSetup1 HCwithEGOnSetup2 HCwithEGOnSetup1;

clear eyegateSetup2 eyegateSetup1 setupRule1 setupRule2 setupRule;
clear initialDataExpereiment1 initialDataExpereiment2 initialDataExpereiment1refined initialDataExpereiment2refined;

expereiment1Data = motionControlled3 + eyeControlled3; %%% cleaned motion control data
eyegate1Data = eyegateOn1 + eyegateOff1; %%% cleaned eye gate data

HCwithEGOff = HCwithEGOff2 + HCwithEGOff1;
HCwithEGOn = HCwithEGOn2 + HCwithEGOn1;
ECwithEGOff = ECwithEGOff2 + ECwithEGOff1;
ECwithEGOn = ECwithEGOn1 + ECwithEGOn2;

clear motionControlled1 motionControlled3 eyeControlled1 eyeControlled3; 
clear eyegateOff1 eyegateOff2 eyegateOn1 eyegateOn2;

clear HCwithEGOff2 HCwithEGOff1 HCwithEGOn2 HCwithEGOn1;
clear ECwithEGOff2 ECwithEGOff1 ECwithEGOn1  ECwithEGOn2;

% HCwithEGOff = 
% HCwithEGOn = 
% ECwithEGOff = 
% ECwithEGOn = 

% final outputs
DataVariables.handControl = expereiment1Data(1:58,1:10);
DataVariables.eyegazeControl = expereiment2Data(1:58,1:10);
DataVariables.eyeGateOn = eyegate1Data;
DataVariables.eyeGateOff = eyegate2Data;

DataVariables.HCwithEGOff = HCwithEGOff;
DataVariables.HCwithEGOn = HCwithEGOn;
DataVariables.ECwithEGOff = ECwithEGOff;
DataVariables.ECwithEGOn = ECwithEGOn;

clear HCwithEGOff HCwithEGOn ECwithEGOff ECwithEGOn;
clear expereiment1Data expereiment2Data eyegate1Data eyegate2Data rows cols;
clear initialDataExpereiment1 initialDataExpereiment2 initialDataExpereiment1refined initialDataExpereiment2refined;

%% finding raw score

[rowsDV, colsDV] = size(DataVariables.handControl);
% processing1 = zeros(rowsDV, colsDV);

for i = 1 : colsDV
    if(mod(i, 2) == 0)
        processing1(:, i) = 5 - DataVariables.handControl(:, i);
        processing2(:, i) = 5 - DataVariables.eyegazeControl(:, i);
        processing3(:, i) = 5 - DataVariables.eyeGateOn(:, i);
        processing4(:, i) = 5 - DataVariables.eyeGateOff(:, i);
        processing5(:, i) = 5 - DataVariables.HCwithEGOff(:, i);
        processing6(:, i) = 5 - DataVariables.HCwithEGOn(:, i);
        processing7(:, i) = 5 - DataVariables.ECwithEGOff(:, i);
        processing8(:, i) = 5 - DataVariables.ECwithEGOn(:, i);
    else
        processing1(:, i) = DataVariables.handControl(:, i) - 1;
        processing2(:, i) = DataVariables.eyegazeControl(:, i) - 1;
        processing3(:, i) = DataVariables.eyeGateOn(:, i) - 1;
        processing4(:, i) = DataVariables.eyeGateOff(:, i) - 1;
        processing5(:, i) = DataVariables.HCwithEGOff(:, i) - 1;
        processing6(:, i) = DataVariables.HCwithEGOn(:, i) - 1;
        processing7(:, i) = DataVariables.ECwithEGOff(:, i) - 1;
        processing8(:, i) = DataVariables.ECwithEGOn(:, i) - 1;
    end
end

% wrong approach, this was only computing 2 columns data each time
% providing wrong sum for rawScores [data in 11th col]  <--- this was the
% problem
% for i = 2 : colsDV
%     DataVariables.handControl(:, colsDV + 1) = processing1(:, i - 1) + processing1(:, i);
%     DataVariables.eyegazeControl(:, colsDV + 1) = processing2(:, i - 1) + processing2(:, i);
%     DataVariables.eyeGateOn(:, colsDV + 1) = processing3(:, i - 1) + processing3(:, i);
%     DataVariables.eyeGateOff(:, colsDV + 1) = processing4(:, i - 1) + processing4(:, i);
% end

% Here sum is calculated row-wise, giving a more accurate sum data in 11th
% col
for i = 1 : rowsDV
    DataVariables.handControl(i, colsDV + 1) = sum(processing1(i, :));
    DataVariables.eyegazeControl(i, colsDV + 1) = sum(processing2(i, :));
    DataVariables.eyeGateOn(i, colsDV + 1) = sum(processing3(i, :));
    DataVariables.eyeGateOff(i, colsDV + 1) = sum(processing4(i, :));
    DataVariables.HCwithEGOff(i, colsDV + 1) = sum(processing5(i, :));
    DataVariables.HCwithEGOn(i, colsDV + 1) = sum(processing6(i, :));
    DataVariables.ECwithEGOff(i, colsDV + 1) = sum(processing7(i, :));
    DataVariables.ECwithEGOn(i, colsDV + 1) = sum(processing8(i, :));
end

clear processing1 processing2 processing3 processing4;
clear processing5 processing6 processing7 processing8;

%% finding sus score

[rowsDV, colsDV] = size(DataVariables.handControl);

DataVariables.handControl(:, colsDV + 1) = DataVariables.handControl(:, colsDV).*2.5;
DataVariables.eyegazeControl(:, colsDV + 1) = DataVariables.eyegazeControl(:, colsDV).*2.5;
DataVariables.eyeGateOn(:, colsDV + 1) = DataVariables.eyeGateOn(:, colsDV).*2.5;
DataVariables.eyeGateOff(:, colsDV + 1) = DataVariables.eyeGateOff(:, colsDV).*2.5;
DataVariables.HCwithEGOff(:, colsDV + 1) = DataVariables.HCwithEGOff(:, colsDV).*2.5;
DataVariables.HCwithEGOn(:, colsDV + 1) = DataVariables.HCwithEGOn(:, colsDV).*2.5;
DataVariables.ECwithEGOff(:, colsDV + 1) = DataVariables.ECwithEGOff(:, colsDV).*2.5;
DataVariables.ECwithEGOn(:, colsDV + 1) = DataVariables.ECwithEGOn(:, colsDV).*2.5;

% Averages
DataVariables.handControl(rowsDV + 1, :) = mean(DataVariables.handControl);
DataVariables.eyegazeControl(rowsDV + 1, :) = mean(DataVariables.eyegazeControl);
DataVariables.eyeGateOn(rowsDV + 1, :) = mean(DataVariables.eyeGateOn);
DataVariables.eyeGateOff(rowsDV + 1, :) = mean(DataVariables.eyeGateOff);


% raw score avg
rawScore.handControlAvg = DataVariables.handControl(rowsDV + 1, colsDV);
rawScore.eyegazeControlAvg = DataVariables.eyegazeControl(rowsDV + 1, colsDV);
rawScore.eyeGateOnAvg = DataVariables.eyeGateOn(rowsDV + 1, colsDV);
rawScore.eyeGateOffAvg = DataVariables.eyeGateOff(rowsDV + 1, colsDV);

% sus score avg
susScore.handControlAvg = DataVariables.handControl(rowsDV + 1, colsDV + 1);
susScore.eyegazeControlAvg = DataVariables.eyegazeControl(rowsDV + 1, colsDV + 1);
susScore.eyeGateOnAvg = DataVariables.eyeGateOn(rowsDV + 1, colsDV + 1);
susScore.eyeGateOffAvg = DataVariables.eyeGateOff(rowsDV + 1, colsDV + 1);

% Min/Mx 
DataVariables.handControl(rowsDV + 2, :) = min(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 2, :) = min(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 2, :) = min(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 2, :) = min(DataVariables.eyeGateOff(1:58, :));

DataVariables.handControl(rowsDV + 3, :) = max(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 3, :) = max(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 3, :) = max(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 3, :) = max(DataVariables.eyeGateOff(1:58, :));

% raw score Min row 60
rawScore.handControlMin = DataVariables.handControl(rowsDV + 2, colsDV);
rawScore.eyegazeControlMin = DataVariables.eyegazeControl(rowsDV + 2, colsDV);
rawScore.eyeGateOnMin = DataVariables.eyeGateOn(rowsDV + 2, colsDV);
rawScore.eyeGateOffMin = DataVariables.eyeGateOff(rowsDV + 2, colsDV);

rawScore.handControlMax = DataVariables.handControl(rowsDV + 3, colsDV);
rawScore.eyegazeControlMax = DataVariables.eyegazeControl(rowsDV + 3, colsDV);
rawScore.eyeGateOnMax = DataVariables.eyeGateOn(rowsDV + 3, colsDV);
rawScore.eyeGateOffMax = DataVariables.eyeGateOff(rowsDV + 3, colsDV);

% sus score Min/Max row 61
susScore.handControlMin = DataVariables.handControl(rowsDV + 2, colsDV + 1);
susScore.eyegazeControlMin = DataVariables.eyegazeControl(rowsDV + 2, colsDV + 1);
susScore.eyeGateOnMin = DataVariables.eyeGateOn(rowsDV + 2, colsDV + 1);
susScore.eyeGateOffMin = DataVariables.eyeGateOff(rowsDV + 2, colsDV + 1);

susScore.handControlMax = DataVariables.handControl(rowsDV + 3, colsDV + 1);
susScore.eyegazeControlMax = DataVariables.eyegazeControl(rowsDV + 3, colsDV + 1);
susScore.eyeGateOnMax = DataVariables.eyeGateOn(rowsDV + 3, colsDV + 1);
susScore.eyeGateOffMax = DataVariables.eyeGateOff(rowsDV + 3, colsDV + 1);

susScore.handControlMin = DataVariables.handControl(rowsDV + 2, colsDV + 1);
susScore.eyegazeControlMin = DataVariables.eyegazeControl(rowsDV + 2, colsDV + 1);
susScore.eyeGateOnMin = DataVariables.eyeGateOn(rowsDV + 2, colsDV + 1);
susScore.eyeGateOffMin = DataVariables.eyeGateOff(rowsDV + 2, colsDV + 1);

susScore.handControlMax = DataVariables.handControl(rowsDV + 3, colsDV + 1);
susScore.eyegazeControlMax = DataVariables.eyegazeControl(rowsDV + 3, colsDV + 1);
susScore.eyeGateOnMax = DataVariables.eyeGateOn(rowsDV + 3, colsDV + 1);
susScore.eyeGateOffMax = DataVariables.eyeGateOff(rowsDV + 3, colsDV + 1);

% Median row 62
DataVariables.handControl(rowsDV + 4, :) = median(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 4, :) = median(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 4, :) = median(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 4, :) = median(DataVariables.eyeGateOff(1:58, :));

% STD row 63
DataVariables.handControl(rowsDV + 5, :) = std(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 5, :) = std(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 5, :) = std(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 5, :) = std(DataVariables.eyeGateOff(1:58, :));

% VAR row 64
DataVariables.handControl(rowsDV + 6, :) = var(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 6, :) = var(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 6, :) = var(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 6, :) = var(DataVariables.eyeGateOff(1:58, :));


% MOde row 65
DataVariables.handControl(rowsDV + 7, :) = mode(DataVariables.handControl(1:58, :));
DataVariables.eyegazeControl(rowsDV + 7, :) = mode(DataVariables.eyegazeControl(1:58, :));
DataVariables.eyeGateOn(rowsDV + 7, :) = mode(DataVariables.eyeGateOn(1:58, :));
DataVariables.eyeGateOff(rowsDV + 7, :) = mode(DataVariables.eyeGateOff(1:58, :));


%% comparisons

% w/o averaging
% xData = categorical({'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
% xData = reordercats(xData, {'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
% yData = [susScore.eyeGateOffAvg susScore.eyeGateOnAvg susScore.eyeGateOffAvg ...
%     susScore.eyeGateOnAvg; susScore.handControlAvg susScore.handControlAvg ...
%     susScore.eyegazeControlAvg susScore.eyegazeControlAvg];
% figure(1)
% bar(xData, yData)

% with averaging
xData = categorical({'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
xData = reordercats(xData, {'HC w/o EG', 'HC w EG', 'EC w/o EG', 'EC w EG'});
yData = [(susScore.eyeGateOffAvg + susScore.handControlAvg)/2; ...
         (susScore.eyeGateOnAvg + susScore.handControlAvg)/2; ...
         (susScore.eyeGateOffAvg + susScore.eyegazeControlAvg)/2; ...
         (susScore.eyeGateOnAvg + susScore.eyegazeControlAvg)/2];

% figure(1)
% gcf=bar(xData, yData);
% gcf(1).DisplayName = 'Xdata VS Ydata';

% 
% figure(2)
% b = bar(xData, yData);
% 
% % HC w/o EG vs EC w/o EG with averaging ++++
% xData = categorical({'HC w/o EG', 'EC w/o EG'});
% xData = reordercats(xData, {'HC w/o EG', 'EC w/o EG'});
% yData = [(susScore.eyeGateOffAvg + susScore.handControlAvg)/2; ...
%          (susScore.eyeGateOffAvg + susScore.eyegazeControlAvg)/2];
% 

% figure(3)
% % HC w/o EG vs EC w/o EG sus data comparison
% % plot(DataVariables.eyeGateOff(1:58, 12), DataVariables.handControl(1:58, 12))
% gcf = plot(sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
%     sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
% gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
% gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
% gcf(1).DisplayName = 'HC w/o EG';
% gcf(2).DisplayName = 'EC w/o EG';
% legend; grid on;

figure(3)
% HC w/o EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateOff(1:58, 12), DataVariables.handControl(1:58, 12))
gcf = plot(1:58, sort(DataVariables.HCwithEGOff(1:58, 12)), 1:58, ...
    sort(DataVariables.ECwithEGOff(1:58, 12)));
gcf(1).Marker = '*';gcf(1).DisplayName = 'HC w/o EG';
gcf(2).Marker = 'o';gcf(2).DisplayName = 'EC w/o EG';
legend; grid on;xlabel('participants'); ylabel('SUS Score');
title('HC w/o EG vs EC w/o EG');


figure(4)
% HC with EG vs EC with EG sus data comparison
% plot(DataVariables.eyeGateOff(1:58, 12), DataVariables.handControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'HC with EG';
gcf(2).DisplayName = 'EC with EG';
legend; grid on;


figure(5)
% HC with EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateon(1:58, 12), DataVariables.handControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'HC with EG';
gcf(2).DisplayName = 'EC w/o EG';
legend; grid on;

figure(6)
% EC with EG vs EC w/o EG sus data comparison
% plot(DataVariables.eyeGateon(1:58, 12), DataVariables.eyegazeControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'EC with EG ';
gcf(2).DisplayName = 'EC w/o EG ';
legend; grid on;

% figure(6)
% % EC w EG vs EC w/o EG sus data comparison
% % plot(DataVariables.eyeGateon(1:58, 12), DataVariables.eyegazeControl(1:58, 12))
% gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)), ...
%     sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.eyegazeControl(1:58, 12)));
% gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
% gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
% gcf(1).DisplayName = 'EC with EG ';
% gcf(2).DisplayName = 'EC w/o EG ';
% legend; grid on;

figure(7)
% HC with EG vs HC w/o EG sus data comparison
% plot(DataVariables.eyeGateon(1:58, 12), DataVariables.eyegazeControl(1:58, 12))
gcf = plot(sort(DataVariables.eyeGateOn(1:58, 12)), sort(DataVariables.handControl(1:58, 12)), ...
    sort(DataVariables.eyeGateOff(1:58, 12)), sort(DataVariables.handControl(1:58, 12)));
gcf(1).Marker = '*'; gcf(1).LineStyle = '--'; gcf(1).LineWidth = 10;
gcf(2).Marker = 'o'; gcf(1).LineStyle = '-'; gcf(1).LineWidth = 2;
gcf(1).DisplayName = 'HC with EG ';
gcf(2).DisplayName = 'HC w/o EG ';
legend; grid on;


%% generating output table

handcontrol = sort(DataVariables.handControl(1:58, 12));
eyegazeControl = sort(DataVariables.eyegazeControl(1:58, 12));
eyeGateOn = sort(DataVariables.eyeGateOn(1:58, 12));
eyeGateOff = sort(DataVariables.eyeGateOff(1:58, 12));

susTable = table(handcontrol, eyegazeControl, eyeGateOn, eyeGateOff);
writetable(susTable, 'susTable.xlsx');

ECwithEGOff = DataVariables.ECwithEGOff(:, 12); 
ECwithEGOn = DataVariables.ECwithEGOn(:, 12); 
HCwithEGOff = DataVariables.HCwithEGOff(:, 12); 
HCwithEGOn = DataVariables.HCwithEGOn(:, 12);

DVTable = table(ECwithEGOff, ECwithEGOn, HCwithEGOff, HCwithEGOn);
writetable(DVTable, 'datavaraibles.xlsx');

clear handcontrol eyegazeControl eyeGateOn eyeGateOff